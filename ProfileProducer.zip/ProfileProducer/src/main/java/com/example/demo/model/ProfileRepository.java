package com.example.demo.model;
import java.util.*;
public interface ProfileRepository {
	List<Profile> getAllProfiles();
	Profile getProfile(String userId);
}
